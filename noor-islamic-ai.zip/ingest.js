import fs from "node:fs";
import { KEY, embed } from "./lib.js";
const docs=JSON.parse(fs.readFileSync(new URL("./data/sources.json",import.meta.url),"utf8"));
if(!KEY) throw new Error("أضف GEMINI_API_KEY إلى إعدادات الاستضافة أولاً.");
if(!Array.isArray(docs)||!docs.length) throw new Error("ملف المصادر فارغ.");
const ids=new Set();
for(const d of docs){ if(!d.id||!d.ref||!d.text||!d.url) throw new Error("كل مصدر يحتاج id وref وtext وurl"); if(ids.has(d.id)) throw new Error("معرّف مصدر مكرر: "+d.id); ids.add(d.id); }
const out=[];
for(let i=0;i<docs.length;i++){const d=docs[i]; const vec=await embed(`${d.ref}\n${d.text}`,"RETRIEVAL_DOCUMENT");out.push({...d,vec});console.log(`فهرسة المصدر ${i+1}/${docs.length}`);}
fs.writeFileSync(new URL("./data/index.json",import.meta.url),JSON.stringify(out));
console.log("اكتمل بناء فهرس المصادر.");
