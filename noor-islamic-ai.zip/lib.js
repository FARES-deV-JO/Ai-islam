import "dotenv/config";
export const KEY = process.env.GEMINI_API_KEY;
const BASE = "https://generativelanguage.googleapis.com/v1beta/models";
const GEN_MODEL = process.env.GEMINI_MODEL || "gemini-2.5-flash";
const EMB_MODEL = "gemini-embedding-001";
async function call(url, body) {
  if (!KEY) throw new Error("GEMINI_API_KEY غير مضبوط");
  const r = await fetch(url, { method:"POST", headers:{"Content-Type":"application/json", "x-goog-api-key":KEY}, body:JSON.stringify(body) });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error?.message || `Gemini API error ${r.status}`);
  return j;
}
export async function embed(text, taskType) {
  const j = await call(`${BASE}/${EMB_MODEL}:embedContent`, {content:{parts:[{text}]}, taskType, outputDimensionality:768});
  if (!j.embedding?.values) throw new Error("تعذر إنشاء التضمين من Gemini");
  return j.embedding.values;
}
export async function generate(system, user) {
  const j = await call(`${BASE}/${GEN_MODEL}:generateContent`, {
    systemInstruction:{parts:[{text:system}]}, contents:[{role:"user",parts:[{text:user}]}],
    generationConfig:{temperature:0.1,responseMimeType:"application/json",maxOutputTokens:1200}
  });
  return j.candidates?.[0]?.content?.parts?.map(p=>p.text||"").join("") || "";
}
export function cosine(a,b) { let d=0,na=0,nb=0; for(let i=0;i<Math.min(a.length,b.length);i++){d+=a[i]*b[i];na+=a[i]**2;nb+=b[i]**2;} return na&&nb?d/(Math.sqrt(na)*Math.sqrt(nb)):0; }
